"""
Dagster definitions for OMC Flywheel Clean Rooms pipeline.
"""
import os
from dagster import Definitions, ScheduleDefinition, DefaultScheduleStatus, EnvVar
from .assets.monthly_refresh import (
    addr_part,
    infobase_part,
    addr_glue_reg,
    infobase_glue_reg,
    glue_ready,
    er_table,
    data_monitor_rpt,
    cr_rpt,
)
from .jobs import monthly_refresh_job, associate_tables_job
from .resources import AWSResource, EnvironmentConfig

# Get environment from env var, default to 'dev'
ENVIRONMENT = os.getenv("DAGSTER_ENV", "dev")

# Monthly refresh schedule (disabled - run manually via UI or CLI)
monthly_refresh_schedule = ScheduleDefinition(
    name="monthly_refresh_schedule",
    job=monthly_refresh_job,
    cron_schedule="0 2 1 * *",  # 2 AM UTC on 1st of month
    default_status=DefaultScheduleStatus.STOPPED,  # Disabled - run manually
)

# Environment-specific configuration
# In production, these values can come from:
# 1. Environment variables (using EnvVar)
# 2. Config files loaded via workspace.yaml
# 3. Secrets management systems

def get_environment_config():
    """Get environment-specific configuration."""
    if ENVIRONMENT == "prod":
        return EnvironmentConfig(
            environment="prod",
            job_names={
                "split_addressable": os.getenv("GLUE_JOB_SPLIT_ADDRESSABLE", "etl-omc-flywheel-prod-addressable-split-and-part"),
                "split_infobase": os.getenv("GLUE_JOB_SPLIT_INFOBASE", "etl-omc-flywheel-prod-infobase-split-and-part"),
                "register_addressable": os.getenv("GLUE_JOB_REGISTER_ADDRESSABLE", "etl-omc-flywheel-prod-register-part-tables"),
                "register_infobase": os.getenv("GLUE_JOB_REGISTER_INFOBASE", "etl-omc-flywheel-prod-register-part-tables"),
                "prepare_tables": os.getenv("GLUE_JOB_PREPARE_TABLES", "etl-omc-flywheel-prod-prepare-part-tables"),
                "create_er_table": os.getenv("GLUE_JOB_CREATE_ER_TABLE", "etl-omc-flywheel-prod-create-part-addressable-ids-er-table"),
                "data_monitor_report": os.getenv("GLUE_JOB_DATA_MONITOR_REPORT", "etl-omc-flywheel-prod-generate-data-monitor-report"),
                "cleanrooms_report": os.getenv("GLUE_JOB_CLEANROOMS_REPORT", "etl-omc-flywheel-prod-generate-cleanrooms-report"),
            },
            database=os.getenv("DATABASE_NAME", "omc_flywheel_prod_clean"),
            s3_root_addressable=os.getenv("S3_ROOT_ADDRESSABLE", "s3://omc-flywheel-data-us-east-1-prod/omc_cleanroom_data/split_part/addressable_ids/"),
            s3_root_infobase=os.getenv("S3_ROOT_INFOBASE", "s3://omc-flywheel-data-us-east-1-prod/omc_cleanroom_data/split_part/infobase_attributes/"),
            role_name=os.getenv("ROLE_NAME", "cleanrooms-glue-s3-access"),
            sns_topic_arn=os.getenv("SNS_TOPIC_ARN"),
        )
    else:  # dev
        return EnvironmentConfig(
            environment="dev",
            job_names={
                "split_addressable": "etl-omc-flywheel-dev-addressable-split-and-part",
                "split_infobase": "etl-omc-flywheel-dev-infobase-split-and-part",
                "register_addressable": "etl-omc-flywheel-dev-register-part-tables",
                "register_infobase": "etl-omc-flywheel-dev-register-part-tables",
                "prepare_tables": "etl-omc-flywheel-dev-prepare-part-tables",
                "create_er_table": "etl-omc-flywheel-dev-create-part-addressable-ids-er-table",
                "data_monitor_report": "etl-omc-flywheel-dev-generate-data-monitor-report",
                "cleanrooms_report": "etl-omc-flywheel-dev-generate-cleanrooms-report",
            },
            database="omc_flywheel_dev_clean",
            s3_root_addressable="s3://omc-flywheel-data-us-east-1-dev/omc_cleanroom_data/split_part/addressable_ids/",
            s3_root_infobase="s3://omc-flywheel-data-us-east-1-dev/omc_cleanroom_data/split_part/infobase_attributes/",
            role_name="cleanrooms-glue-s3-access",
            sns_topic_arn="arn:aws:sns:us-east-1:417649522250:omc-flywheel-dev-db-refresh-notifications",
        )

defs = Definitions(
    assets=[
        addr_part,
        infobase_part,
        addr_glue_reg,
        infobase_glue_reg,
        glue_ready,
        er_table,
        data_monitor_rpt,
        cr_rpt,
    ],
    jobs=[monthly_refresh_job, associate_tables_job],
    schedules=[monthly_refresh_schedule],
    resources={
        # AWS Resource: Use environment variable for profile in production, or default to dev profile
        # In production, AWS credentials should come from IAM role, not profile
        "aws": AWSResource(
            aws_profile=os.getenv("AWS_PROFILE", "flywheel-dev" if ENVIRONMENT == "dev" else None),
            aws_region=os.getenv("AWS_REGION", "us-east-1"),
            verify_ssl=os.getenv("VERIFY_SSL", "false").lower() == "true",
        ),
        # Environment Config: All values provided, so no runtime config needed
        "config": get_environment_config(),
    },
)
