"""
Monthly Refresh - Step 4: Create ER Table
Creates Entity Resolution table for addressable IDs.
"""
from dagster import asset, AssetExecutionContext
from typing import Dict, Any
from ...resources import AWSResource, EnvironmentConfig
from .split_jobs import _run_glue_job
from .prepare_tables import glue_ready


@asset(
    group_name="monthly_refresh",
    description="Step 4: Entity Resolution table for addressable IDs"
)
def er_table(
    context: AssetExecutionContext,
    aws: AWSResource,
    config: EnvironmentConfig,
    glue_ready: Dict[str, Any]
) -> Dict[str, Any]:
    """Entity Resolution table for addressable IDs."""
    job_args = config.get_job_args("create_er_table")
    return _run_glue_job(context, aws, config, "create_er_table", job_args)

