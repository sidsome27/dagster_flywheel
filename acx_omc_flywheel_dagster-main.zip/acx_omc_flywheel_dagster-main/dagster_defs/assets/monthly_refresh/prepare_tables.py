"""
Monthly Refresh - Step 3: Prepare Part Tables
Prepares partitioned tables for Clean Rooms.
"""
from dagster import asset, AssetExecutionContext
from typing import Dict, Any
from ...resources import AWSResource, EnvironmentConfig
from .split_jobs import _run_glue_job
from .register_tables import addr_glue_reg, infobase_glue_reg


@asset(
    group_name="monthly_refresh",
    description="Step 3: Query-ready state (tables + partitions repaired and validated)"
)
def glue_ready(
    context: AssetExecutionContext,
    aws: AWSResource,
    config: EnvironmentConfig,
    addr_glue_reg: Dict[str, Any],
    infobase_glue_reg: Dict[str, Any]
) -> Dict[str, Any]:
    """Query-ready state (tables + partitions repaired and validated)."""
    job_args = config.get_job_args("prepare_tables")
    return _run_glue_job(context, aws, config, "prepare_tables", job_args)

