"""
Monthly Refresh - Step 5: Generate Reports
Generates Data Monitor and Cleanrooms reports (parallel execution).
"""
from dagster import asset, AssetExecutionContext
from typing import Dict, Any
from ...resources import AWSResource, EnvironmentConfig
from .split_jobs import _run_glue_job
from .er_table import er_table


@asset(
    group_name="monthly_refresh",
    description="Step 5A: Data Monitor report artifact"
)
def data_monitor_rpt(
    context: AssetExecutionContext,
    aws: AWSResource,
    config: EnvironmentConfig,
    er_table: Dict[str, Any]
) -> Dict[str, Any]:
    """Data Monitor report artifact."""
    job_args = config.get_job_args("data_monitor_report")
    return _run_glue_job(context, aws, config, "data_monitor_report", job_args)


@asset(
    group_name="monthly_refresh",
    description="Step 5B: Cleanrooms report artifact"
)
def cr_rpt(
    context: AssetExecutionContext,
    aws: AWSResource,
    config: EnvironmentConfig,
    er_table: Dict[str, Any]
) -> Dict[str, Any]:
    """Cleanrooms report artifact."""
    job_args = config.get_job_args("cleanrooms_report")
    return _run_glue_job(context, aws, config, "cleanrooms_report", job_args)

