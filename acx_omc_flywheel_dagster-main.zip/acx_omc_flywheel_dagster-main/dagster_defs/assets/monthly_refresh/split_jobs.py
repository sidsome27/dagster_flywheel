"""
Monthly Refresh - Step 1: Parallel Split Jobs
Splits addressable IDs and infobase data into partitioned tables.
"""
from dagster import asset, AssetExecutionContext
from typing import Dict, Any
from ...resources import AWSResource, EnvironmentConfig
import time


def _run_glue_job(
    context: AssetExecutionContext,
    aws: AWSResource,
    config: EnvironmentConfig,
    job_key: str,
    job_args: Dict[str, str]
) -> Dict[str, Any]:
    """Helper to run a Glue job and wait for completion."""
    job_name = config.get_job_name(job_key)
    
    context.log.info(f"Starting Glue job: {job_name}")
    context.log.debug(f"Job arguments: {job_args}")
    
    # Start job
    response = aws.glue_client.start_job_run(
        JobName=job_name,
        Arguments=job_args
    )
    
    run_id = response['JobRunId']
    context.log.info(f"Job started with Run ID: {run_id}")
    
    # Poll for completion
    max_wait_time = 3600  # 1 hour timeout
    poll_interval = 30  # Check every 30 seconds
    start_time = time.time()
    
    while time.time() - start_time < max_wait_time:
        job_run = aws.glue_client.get_job_run(
            JobName=job_name,
            RunId=run_id
        )
        
        state = job_run['JobRun']['JobRunState']
        context.log.info(f"Job state: {state}")
        
        if state == 'SUCCEEDED':
            context.log.info(f"✅ Job {job_name} completed successfully")
            return {
                'run_id': run_id,
                'state': state,
                'execution_time': job_run['JobRun'].get('ExecutionTime', 0)
            }
        elif state in ['FAILED', 'ERROR', 'TIMEOUT']:
            error_msg = job_run['JobRun'].get('ErrorMessage', 'Unknown error')
            context.log.error(f"❌ Job {job_name} failed: {error_msg}")
            raise Exception(f"Glue job {job_name} failed: {error_msg}")
        
        time.sleep(poll_interval)
    
    raise Exception(f"Job {job_name} timed out after {max_wait_time} seconds")


@asset(
    group_name="monthly_refresh",
    description="Step 1A: Partitioned addressable IDs dataset"
)
def addr_part(
    context: AssetExecutionContext,
    aws: AWSResource,
    config: EnvironmentConfig
) -> Dict[str, Any]:
    """Partitioned addressable IDs dataset."""
    job_args = config.get_job_args("split_addressable")
    return _run_glue_job(context, aws, config, "split_addressable", job_args)


@asset(
    group_name="monthly_refresh",
    description="Step 1B: Partitioned infobase attributes dataset"
)
def infobase_part(
    context: AssetExecutionContext,
    aws: AWSResource,
    config: EnvironmentConfig
) -> Dict[str, Any]:
    """Partitioned infobase attributes dataset."""
    job_args = config.get_job_args("split_infobase")
    return _run_glue_job(context, aws, config, "split_infobase", job_args)

