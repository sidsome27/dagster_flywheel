"""
Monthly Refresh - Step 2: Register Part Tables
Registers partitioned tables in Glue catalog (parallel execution).
"""
from dagster import asset, AssetExecutionContext
from typing import Dict, Any
from ...resources import AWSResource, EnvironmentConfig
from .split_jobs import addr_part, infobase_part, _run_glue_job


@asset(
    group_name="monthly_refresh",
    description="Step 2A: Addressable IDs tables registered in Glue catalog"
)
def addr_glue_reg(
    context: AssetExecutionContext,
    aws: AWSResource,
    config: EnvironmentConfig,
    addr_part: Dict[str, Any]  # Input from previous asset
) -> Dict[str, Any]:
    """Addressable IDs tables registered in Glue catalog."""
    job_args = config.get_job_args("register_addressable")
    return _run_glue_job(context, aws, config, "register_addressable", job_args)


@asset(
    group_name="monthly_refresh",
    description="Step 2B: Infobase attributes tables registered in Glue catalog"
)
def infobase_glue_reg(
    context: AssetExecutionContext,
    aws: AWSResource,
    config: EnvironmentConfig,
    infobase_part: Dict[str, Any]  # Input from previous asset
) -> Dict[str, Any]:
    """Infobase attributes tables registered in Glue catalog."""
    job_args = config.get_job_args("register_infobase")
    return _run_glue_job(context, aws, config, "register_infobase", job_args)

