"""
AWS Resource definitions for Dagster.
Provides boto3 clients for Glue and Clean Rooms operations.
"""
from dagster import ConfigurableResource, InitResourceContext
import boto3
from botocore.config import Config
from typing import Optional
import os
import ssl
import urllib3

# Disable SSL warnings for development
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
os.environ.setdefault('PYTHONHTTPSVERIFY', '0')
ssl._create_default_https_context = ssl._create_unverified_context


class AWSResource(ConfigurableResource):
    """AWS resource providing boto3 clients for Glue and Clean Rooms."""
    
    aws_profile: Optional[str] = None
    aws_region: str = "us-east-1"
    verify_ssl: bool = False
    
    def setup_for_execution(self, context: InitResourceContext) -> None:
        """Log AWS resource initialization."""
        context.log.info(f"AWS resource initialized (profile: {self.aws_profile or 'default'}, region: {self.aws_region})")
    
    @property
    def _session(self):
        """Get or create boto3 session."""
        if self.aws_profile:
            return boto3.Session(profile_name=self.aws_profile)
        return boto3.Session()
    
    @property
    def _boto_config(self):
        """Get boto3 config with timeouts."""
        return Config(
            connect_timeout=60,
            read_timeout=60,
            retries={'max_attempts': 3}
        )
    
    @property
    def glue_client(self):
        """Get Glue client."""
        return self._session.client(
            'glue',
            region_name=self.aws_region,
            config=self._boto_config,
            verify=self.verify_ssl
        )
    
    @property
    def cleanrooms_client(self):
        """Get Clean Rooms client."""
        return self._session.client(
            'cleanrooms',
            region_name=self.aws_region,
            config=self._boto_config,
            verify=self.verify_ssl
        )
    
    @property
    def sns_client(self):
        """Get SNS client."""
        return self._session.client(
            'sns',
            region_name=self.aws_region,
            config=self._boto_config,
            verify=self.verify_ssl
        )

