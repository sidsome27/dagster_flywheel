"""
Configuration resource for environment-specific settings.
"""
from dagster import ConfigurableResource
from typing import Dict, Optional


class EnvironmentConfig(ConfigurableResource):
    """Environment-specific configuration for jobs and assets."""
    
    environment: str  # 'dev' or 'prod'
    
    # Glue job names
    job_names: Dict[str, str]
    
    # Database and S3 paths
    database: str
    s3_root_addressable: str
    s3_root_infobase: str
    
    # Clean Rooms settings
    role_name: str = "cleanrooms-glue-s3-access"
    
    # SNS topic ARN (optional)
    sns_topic_arn: Optional[str] = None
    
    def get_job_name(self, job_key: str) -> str:
        """Get job name by key."""
        return self.job_names.get(job_key, "")
    
    def get_job_args(self, job_key: str, snapshot_dt: Optional[str] = None) -> Dict[str, str]:
        """Get job arguments by key."""
        args = {}
        
        if snapshot_dt:
            args["--SNAPSHOT_DT"] = snapshot_dt
        
        if job_key == "register_addressable":
            args.update({
                "--DATABASE": self.database,
                "--S3_ROOT": self.s3_root_addressable,
                "--TABLE_PREFIX": "part_",
                "--MAX_COLS": "100"
            })
        elif job_key == "register_infobase":
            args.update({
                "--DATABASE": self.database,
                "--S3_ROOT": self.s3_root_infobase,
                "--TABLE_PREFIX": "part_",
                "--MAX_COLS": "100"
            })
        
        return args

