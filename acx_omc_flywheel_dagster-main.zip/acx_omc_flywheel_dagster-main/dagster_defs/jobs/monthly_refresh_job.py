"""
Monthly Refresh Job
Orchestrates the complete 8-asset database refresh workflow.
"""
from dagster import define_asset_job, AssetSelection
from ..assets.monthly_refresh import (
    addr_part,
    infobase_part,
    addr_glue_reg,
    infobase_glue_reg,
    glue_ready,
    er_table,
    data_monitor_rpt,
    cr_rpt,
)

monthly_refresh_job = define_asset_job(
    name="monthly_refresh",
    description="Complete monthly database refresh workflow (8 assets)",
    selection=AssetSelection.all(),
)

