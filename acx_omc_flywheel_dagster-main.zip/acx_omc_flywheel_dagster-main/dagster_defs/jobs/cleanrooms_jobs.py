"""
Clean Rooms Jobs
On-demand jobs for Clean Rooms collaboration management.
"""
from dagster import job
from ..ops.cleanrooms import associate_tables_to_collaboration

@job(
    description="Associate configured tables with a Clean Rooms collaboration"
)
def associate_tables_job():
    """Job to associate tables to a collaboration."""
    associate_tables_to_collaboration()

