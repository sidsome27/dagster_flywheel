"""
Clean Rooms Operations: Table Associations
Operations for associating configured tables with collaborations.
"""
from dagster import op, OpExecutionContext, Config
from typing import List, Dict, Any, Optional
from ...resources import AWSResource
from pydantic import Field


class AssociateTablesConfig(Config):
    """Configuration for associating tables to a collaboration."""
    membership_id: str = Field(description="Clean Rooms membership ID")
    table_prefix: str = Field(default="part_", description="Prefix for tables to associate")
    exclude_tables: List[str] = Field(default_factory=lambda: ["n_a", "n_a_a"], description="Tables to exclude")
    role_name: str = Field(default="cleanrooms-glue-s3-access", description="IAM role name for associations")
    max_associations: int = Field(default=25, description="Maximum number of associations (AWS quota)")


@op(
    description="Associate configured tables with a Clean Rooms collaboration membership"
)
def associate_tables_to_collaboration(
    context: OpExecutionContext,
    config: AssociateTablesConfig,
    aws: AWSResource
) -> Dict[str, Any]:
    """
    Discover and associate configured tables (matching prefix) with a collaboration.
    
    This operation:
    1. Discovers all configured tables matching the prefix
    2. Excludes specified tables
    3. Associates up to max_associations tables with the membership
    4. Creates associations with naming: acx_<table_name>
    """
    context.log.info(f"Associating tables to membership: {config.membership_id}")
    context.log.info(f"Table prefix: {config.table_prefix}, Exclude: {config.exclude_tables}")
    
    # Get IAM role ARN
    try:
        iam = aws.session.client('iam')
        role_response = iam.get_role(RoleName=config.role_name)
        role_arn = role_response['Role']['Arn']
        context.log.info(f"Using IAM role: {role_arn}")
    except Exception as e:
        context.log.error(f"Failed to get IAM role: {e}")
        raise
    
    # Discover configured tables
    tables = []
    paginator = aws.cleanrooms_client.get_paginator('list_configured_tables')
    
    for page in paginator.paginate():
        for table in page.get('configuredTableSummaries', []):
            table_name = table['name']
            # Match prefix and exclude specified tables
            if (table_name.startswith(config.table_prefix) and 
                not any(excluded in table_name for excluded in config.exclude_tables)):
                tables.append({
                    'id': table['id'],
                    'name': table_name
                })
    
    context.log.info(f"Discovered {len(tables)} configured tables")
    
    if len(tables) > config.max_associations:
        context.log.warning(f"Found {len(tables)} tables, limiting to {config.max_associations} (AWS quota)")
        tables = tables[:config.max_associations]
    
    # Get existing associations
    existing_associations = {}
    paginator = aws.cleanrooms_client.get_paginator('list_configured_table_associations')
    for page in paginator.paginate(membershipIdentifier=config.membership_id):
        for assoc in page.get('configuredTableAssociationSummaries', []):
            existing_associations[assoc['configuredTableId']] = assoc['id']
    
    context.log.info(f"Found {len(existing_associations)} existing associations")
    
    # Associate tables
    results = {
        'success': [],
        'skipped': [],
        'failed': []
    }
    
    for table in tables:
        table_id = table['id']
        table_name = table['name']
        association_name = f"acx_{table_name}"
        
        # Skip if already associated
        if table_id in existing_associations:
            context.log.info(f"⏭️  Already associated: {table_name}")
            results['skipped'].append({
                'table': table_name,
                'association_id': existing_associations[table_id]
            })
            continue
        
        try:
            response = aws.cleanrooms_client.create_configured_table_association(
                membershipIdentifier=config.membership_id,
                configuredTableIdentifier=table_id,
                name=association_name,
                roleArn=role_arn
            )
            
            assoc_id = response['configuredTableAssociation']['id']
            context.log.info(f"✅ Associated: {table_name} → {association_name} (ID: {assoc_id})")
            results['success'].append({
                'table': table_name,
                'association_id': assoc_id
            })
            
        except Exception as e:
            context.log.error(f"❌ Failed to associate {table_name}: {e}")
            results['failed'].append({
                'table': table_name,
                'error': str(e)
            })
    
    context.log.info(f"\n📊 Summary:")
    context.log.info(f"  ✅ Success: {len(results['success'])}")
    context.log.info(f"  ⏭️  Skipped: {len(results['skipped'])}")
    context.log.info(f"  ❌ Failed: {len(results['failed'])}")
    
    return results

