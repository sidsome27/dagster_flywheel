"""Clean Rooms operations."""
from .associations import associate_tables_to_collaboration, AssociateTablesConfig

__all__ = [
    "associate_tables_to_collaboration",
    "AssociateTablesConfig",
]

